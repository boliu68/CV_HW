#ifndef WORKSTATES_H
#define WORKSTATES_H

//work mode
#define image_only 1
#define image_only_contour 2

//debug mode
#define pixel_node 3
#define cost_graph 4
#define path_tree 5
#define min_path 6

#endif